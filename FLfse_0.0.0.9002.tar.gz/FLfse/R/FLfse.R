### import S4 methods
#' @import methods
NULL

### import all functionality from FLCore
#' @import FLCore
NULL

### import from utils: capture output
### avoid message while fitting SAM / SPiCT
#' @importFrom utils capture.output
NULL
